import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  title = 'Public';
  tasksloaded: boolean;
  tasks = [];
  onetaskloaded: boolean;
  onetask = [];
  constructor(private _httpService: HttpService){ 
  }

  ngOnInit(){
    this.tasksloaded = false
    this.onetaskloaded = false
    //this.getTasksFromService()
  }

  getTasksFromService(){
    let observable = this._httpService.getTasks()
    observable.subscribe(data =>{
      //console.log("Got our data", data)
      this.tasksloaded = true
      this.tasks = data['tasks']
      console.log(this.tasks)
    })
  }

  getOneTask(id){
    console.log(id)
    for(var task in this.tasks){
      console.log(this.tasks[task])
      if (this.tasks[task]._id === id){
        this.onetask = this.tasks[task]
      }
    }
    this.onetaskloaded = true
    console.log(this.onetask)
  }

  do(event){
    console.log("event is working", event)
  }

  say(value){
    console.log(value)
  }
}
